﻿function openListAccount() {
    window.open('https://'+myURL + '/Account/ListAccount', '_self');
}

function openCreateUser() {
    window.open('https://' + myURL + '/Account/CreateUser', '_self');
}